# 📊 StartSe · KAM Sales Analytics 2026

Painel de análise de performance do time B2B (KAMs), desenvolvido para uso interno do time de **FP&A**, **RevOps** e **Diretoria**.

---

## 🚀 Como usar

### 1. Instalar dependências
```bash
pip install -r requirements.txt
```

### 2. Colocar os arquivos de dados na mesma pasta
```
kam_dashboard/
├── app.py
├── requirements.txt
├── README.md
├── vendas_por_kam__2026_.xlsx          ← base de vendas
└── Analise_cohort_vendas_receita_2026_B2B__2_.xlsx  ← orçamento / cohort
```

### 3. Rodar o app
```bash
streamlit run app.py
```

O navegador abrirá automaticamente em `http://localhost:8501`

---

## 📁 Estrutura esperada dos arquivos Excel

### `vendas_por_kam__2026_.xlsx` (aba `Sheet1`)
Colunas utilizadas: `Guid`, `Data`, `Mês`, `Total`, `Quantidade`, `Status_financeiro`, `Vendedor`, `Produto`, `Verticais`, `Canal`

### `Analise_cohort_vendas_receita_2026_B2B__2_.xlsx`
- Aba `Cohort venda x receita 2026`: Cohort de receita Corporate e Consulting
- Aba `Venda x Mês 2026 KAM - Caio`: Meta individual por KAM
- Aba `Sheet1`: Orçamento anual por BU

---

## 📊 Funcionalidades

| Aba | Descrição |
|-----|-----------|
| 📅 Volume por Mês | Valor e quantidade de vendas mês a mês, empilhado por KAM |
| 👤 Performance KAM | Ranking por volume, scatter valor × taxa de pagamento, tabela detalhada |
| 💳 Qualidade da Carteira | Status financeiro (Pago / Atraso / ??) por KAM e mês, heatmap de risco |
| 📦 Produtos | Treemap, ranking, heatmap KAM × produto, top produtos por KAM |
| 🎯 Meta vs Realizado | Receita realizada vs. meta mensal, % atingimento, cohort de vendas B2B |

---

## 🔧 Filtros disponíveis (sidebar)

- **Mês**: filtra os meses de análise
- **KAM**: seleciona quais vendedores incluir
- **Status Financeiro**: Pago, Adimplente, Em Atraso, Não Iniciado, ??
- **Valor da Venda**: slider de range de valor
- **Grupo de Produto**: categoria do produto vendido

---

## 🔄 Atualização dos dados

Basta substituir os arquivos `.xlsx` na pasta com versões mais recentes — o app recarrega automaticamente (ou use `R` no teclado para forçar refresh).

---

## 🧩 Tecnologias

- **Streamlit** — interface web interativa
- **Plotly** — gráficos interativos
- **Pandas** — processamento de dados
- **OpenPyXL** — leitura de Excel

---

_StartSe · Internal Tool · FP&A / RevOps / Diretoria_
